큐티하니 FX PC-FX POC01 v0.02 - 좌우반전 수정판
=================================================
v0.01 실기/에뮬 검수 결과: 커스텀 V810/KING/KRAM 출력은 성공했으나 전체 화면이 좌우 반전됨.
v0.02 수정: 256x96 소스 비트맵을 KRAM 삽입 전에 미리 좌우반전하여 실제 표시 결과를 정상 방향으로 보정.

부모롬 CLEAN 고정:
Track 1 SHA-1 ffae85763f581d312abb6b5096f6f7d62e771aae
Track 2 SHA-1 1dd574364e40cb90dd0ff25940fe8df9e6793edf

사용법:
1) 원본 Track 1 + Track 2와 POC01_v002_MirrorFix_Patcher.exe를 같은 폴더에 둡니다.
2) EXE를 더블클릭합니다.
3) 생성된 `Cutey Honey FX (Japan) [KR POC01 v0.02].cue`를 실행합니다.

정상 목표:
한글 출력 성공
CUTIE HONEY FX
KR POC01 v0.02
