큐티하니 FX PC-FX 한글 출력 POC01 v0.02
=========================================
v0.01의 CMD 드래그 인자 문제를 제거한 Windows 독립 실행형 패처입니다.
Python 필요 없음. BAT 필요 없음.

가장 쉬운 적용법
1. CLEAN 원본 파일 이름을 Cutey_Honey_FX_JAP.bin 으로 둡니다.
2. 원본 BIN과 POC01_Patcher.exe를 같은 폴더에 둡니다.
3. POC01_Patcher.exe를 더블클릭합니다.
4. [PASS]가 나오면 Cutey_Honey_FX_JAP_KR_POC01.bin 이 생성됩니다.
5. 동봉 Cutey_Honey_FX_JAP_KR_POC01.cue와 생성 BIN을 같은 폴더에 두고 CUE로 부팅합니다.

또는 원본 BIN을 POC01_Patcher.exe 위로 드래그해도 됩니다.

CLEAN 검증값
SIZE    666356880 bytes
SHA-256 a19b406a85576f7e5e928f3f308307aae6b95a0de87b5be60acb4c68f1c08267

패치 후 SHA-256
a381e116de4a53db09ceb6d1f5af4dd02b81976788805275eaf1cc22e5b1c46f

정상 화면: 한글 출력 성공 / CUTIE HONEY FX / KR POC01
