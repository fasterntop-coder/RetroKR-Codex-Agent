@echo off
chcp 65001 >nul
if "%~1"=="" (
  echo 원본 단일 BIN을 이 BAT 파일 위로 끌어다 놓으세요.
  pause
  exit /b 1
)
py -3 "%~dp0apply_poc01.py" "%~1"
pause
