import sys,hashlib,shutil,pathlib
EXPECTED_SIZE=666356880
EXPECTED_SHA="a19b406a85576f7e5e928f3f308307aae6b95a0de87b5be60acb4c68f1c08267"
OFFSET=10337040
HERE=pathlib.Path(__file__).resolve().parent
if len(sys.argv)<2:
 print("Usage: py -3 apply_poc01.py <Cutey_Honey_FX_JAP.bin> [output.bin]"); raise SystemExit(2)
src=pathlib.Path(sys.argv[1]); dst=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else src.with_name("Cutey_Honey_FX_JAP_KR_POC01.bin")
if src.stat().st_size!=EXPECTED_SIZE: raise SystemExit(f"ERROR size {src.stat().st_size} expected {EXPECTED_SIZE}")
h=hashlib.sha256()
with src.open("rb") as f:
 while True:
  b=f.read(8*1024*1024)
  if not b: break
  h.update(b)
if h.hexdigest()!=EXPECTED_SHA: raise SystemExit(f"ERROR SHA256 {h.hexdigest()} expected {EXPECTED_SHA}")
shutil.copyfile(src,dst)
blob=(HERE/"poc01_raw_sectors.bin").read_bytes()
with dst.open("r+b") as f:
 f.seek(OFFSET); f.write(blob)
print("[PASS] POC01 created:",dst)
