큐티하니 FX PC-FX 한글 출력 POC01
=================================
목적: 게임 전체 한글화가 아니라 PC-FX에서 커스텀 한글 glyph 출력 경로를 실기로 최초 확인하는 부트 POC입니다.
정상 결과: 부팅 후 화면에 "한글 출력 성공", "CUTIE HONEY FX", "KR POC01"이 표시되고 그대로 유지됩니다.

가장 쉬운 적용법
1) 원본 단일 BIN을 apply_poc01.bat 위로 드래그합니다.
2) 같은 폴더에 Cutey_Honey_FX_JAP_KR_POC01.bin 이 생성됩니다.
3) 제공 CUE와 생성 BIN을 같은 폴더에 둡니다.
4) Mednafen/실기 환경에서 CUE로 부팅합니다.

BAT는 Windows의 py -3(Python)를 사용합니다. Python이 없으면 동봉 xdelta를 평소 쓰는 xdelta 패처로 원본 BIN에 적용해도 됩니다.
원본 크기/SHA-256은 적용 전에 자동 검증합니다.
POC 화면이 확인되면 다음 빌드부터 이 커스텀 glyph 경로를 원본 게임의 대사 렌더러에 연결합니다.
