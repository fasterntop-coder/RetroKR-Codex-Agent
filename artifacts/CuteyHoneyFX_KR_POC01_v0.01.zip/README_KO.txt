큐티하니 FX PC-FX 한글 출력 POC01 v0.01
========================================
이 빌드는 전체 한글패치가 아니라 최초 한글 glyph 출력 확인용 부트 POC입니다.
정상 결과: 부팅 후 화면 중앙에 "한글 출력 성공", 아래에 "CUTIE HONEY FX", "KR POC01"이 표시됩니다.

적용법 A - 가장 간단함
1. 이 ZIP을 풀어 둡니다.
2. CLEAN 원본 단일 BIN Cutey_Honey_FX_JAP.bin 을 apply_poc01.bat 위로 드래그합니다.
3. Cutey_Honey_FX_JAP_KR_POC01.bin 이 생성됩니다.
4. 동봉 CUE와 생성된 BIN을 같은 폴더에 두고 CUE로 실행합니다.

적용법 B - xdelta
동봉 Cutey_Honey_FX_KR_POC01_v0.01.xdelta 를 CLEAN 원본 단일 BIN에 적용합니다.

CLEAN 검증값
SIZE 666356880 bytes
SHA-256 a19b406a85576f7e5e928f3f308307aae6b95a0de87b5be60acb4c68f1c08267

POC01은 원본 부트 영역만 임시 PC-FX V810/KING 한글 출력 프로그램으로 교체합니다.
한글 출력 확인 후 다음 단계에서 원본 게임의 대사 렌더러에 커스텀 한글 폰트를 연결합니다.
