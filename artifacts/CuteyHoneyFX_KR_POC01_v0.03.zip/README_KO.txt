큐티하니 FX PC-FX 한글 출력 POC01 v0.03
=========================================
사용자 원본 SHA-256 2b93b92a63ff6fc3e5580212ff091fe44cb6189826095f2af5e17ad6d5665dcb 대응판.
v0.02의 Redump SHA 단일 강제검사를 제거하고 실제 PC-FX 구조를 검사합니다.

적용법
1. 원본 Cutey_Honey_FX_JAP.bin 과 POC01_Patcher_v003.exe를 같은 폴더에 둡니다.
2. POC01_Patcher_v003.exe를 더블클릭합니다.
3. 패처가 파일 크기, MODE1 바이트, PC-FX:Hu_CD-ROM 부트 매직을 검사합니다.
4. 모두 PASS하면 Cutey_Honey_FX_JAP_KR_POC01.bin 을 만듭니다.
5. 동봉 CUE와 생성 BIN을 같은 폴더에 두고 CUE로 부팅합니다.

정상 화면
한글 출력 성공
CUTIE HONEY FX
KR POC01

참고: 원본 전체 SHA가 Redump와 달라도 디스크 구조 검증을 통과하면 패치를 진행합니다.
패치 후에는 삽입한 14,112바이트를 다시 읽어 완전 일치 여부를 검증합니다.
