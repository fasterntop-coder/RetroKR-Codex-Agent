큐티하니 FX PC-FX 한글 출력 POC01 - 분리 트랙 Redump 전용
=========================================================
새 부모롬: Cutey Honey FX (Japan) Redump Track 1 + Track 2

CLEAN 기준
Track 1: 9,807,840 bytes
         SHA-1 ffae85763f581d312abb6b5096f6f7d62e771aae
Track 2: 656,549,040 bytes
         SHA-1 1dd574364e40cb90dd0ff25940fe8df9e6793edf

사용법
1. 새 원본 ZIP을 먼저 압축 해제합니다.
2. Track 1 BIN, Track 2 BIN과 POC01_SplitTrack_Patcher.exe를 같은 폴더에 둡니다.
3. POC01_SplitTrack_Patcher.exe를 더블클릭합니다.
   또는 Track 2 BIN을 EXE 위로 드래그합니다.
4. 두 트랙 모두 CLEAN 검증 PASS 후 패치가 진행됩니다.
5. 생성된 `Cutey Honey FX (Japan) [KR POC01].cue`로 부팅합니다.

패치 위치
Track 2 raw offset 0x00081330 (INDEX 01 앞 225 raw sectors 뒤)
패치 길이 14,112 bytes (6 raw sectors)

정상 목표 화면
한글 출력 성공
CUTIE HONEY FX
KR POC01

이 POC01은 원본 게임 내 대사가 아니라 PC-FX 커스텀 한글 출력 경로 검증입니다.
