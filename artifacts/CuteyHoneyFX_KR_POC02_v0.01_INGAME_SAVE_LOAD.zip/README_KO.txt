큐티하니 FX PC-FX POC02 v0.01 — 원본 게임 내 한글 출력 테스트
==================================================================
부모롬: Redump 일본판 분리 Track 1 + Track 2 (POC01과 동일 CLEAN)

목표:
  セーブする -> 저장하기
  ロードする -> 불러오기

이번 버전은 POC01처럼 별도 부트화면을 띄우지 않습니다.
원본 게임을 그대로 부팅하면서 원본 텍스트 렌더러의 BIOS ROMFONT 호출을 후킹합니다.

사용법:
1) CLEAN Track 1 BIN + CLEAN Track 2 BIN + EXE를 같은 폴더에 둡니다.
2) POC02_v001_INGAME_SAVE_LOAD_KR_Patcher.exe 실행
3) 생성된 `Cutey Honey FX (Japan) [KR POC02 v0.01].cue`로 실행
4) 세이브/로드 선택 문구가 나오는 화면에서 한글 여부를 확인

상태: STATIC BUILD PASS / PRE-HW
실기/에뮬레이터 사용자 검증 전에는 HW PASS가 아닙니다.
